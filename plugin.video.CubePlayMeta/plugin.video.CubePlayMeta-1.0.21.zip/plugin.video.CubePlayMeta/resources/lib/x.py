# -*- coding: utf-8 -*-
import xbmc
#dbID = xbmc.getInfoLabel('ListItem.DBID')
#dbType = xbmc.getInfoLabel('ListItem.DBTYPE')
#filePath = xbmc.getInfoLabel('ListItem.FolderPath')
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse
from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

AddonID = 'plugin.video.CubePlayMeta'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import common

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
if not os.path.exists(cacheDir):
	os.makedirs(cacheDir)

cFonte1 = Addon.getSetting("cFonte1")
cFonte2 = Addon.getSetting("cFonte2")
cFonte3 = Addon.getSetting("cFonte3")

cTxt1 = Addon.getSetting("cTxt1")
cTxt2 = Addon.getSetting("cTxt2")
cTxt3 = Addon.getSetting("cTxt3")

DirM = Addon.getSetting("cDir")
DirB = Addon.getSetting("cDirB")
CEle = Addon.getSetting("cEle")

DirCount = Addon.getSetting("DirCount") if Addon.getSetting("DirCount") != "" else 0

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "0" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False

Cat = Addon.getSetting("Cat") if Addon.getSetting("Cat") != "" else 0
Cat2 = Addon.getSetting("Cat2") if Addon.getSetting("Cat2") != "" else "0"
Cidi = Addon.getSetting("Cidi") if Addon.getSetting("Cidi") != "" else "0"
Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else None
Clista=["Sem filtro (Mostrar Todos)","Ação", "Animação", "Aventura", "Crime", "Comédia", "Documentário", "Drama", "Fantasia", "Ficção científica", "Mistério", "Romance", "Terror", 'Thriller']
CImdb=["nome","ano","vote"]
CImdb2=["Nome","Ano","Rating"]


def AddDir2(name, url, mode, iconimage='', logos='', index="", move=0, isFolder=True, IsPlayable=False, background=None, cacheMin='0', info='', DL='', year='', metah={}, episode='', playcount=None): #add2
	urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'cache': cacheMin, 'index': index, 'info': info, 'background': background, 'DL': DL, 'year': year, 'metah': metah, 'episode': episode, 'playcount': playcount, 'index': index}
	if metah:
		if background and episode:
			eInfo = mg.get_episode_details(metah['tmdb_id'], SEAS(background), EPI(episode), ignore_cache=MUcacheEpi, lang=MUlang)
			eInfo2 = mergedicts(metah,eInfo)
			#eInfo2['imagepi'] = eInfo2['imagepi'].replace("/original/","/w780/")
			#eInfo2['cover_url'] = eInfo2['cover_url'].replace("/original/","/w500/")
			#eInfo2['backdrop_url'] = eInfo2['backdrop_url'].replace("/original/","/w780/")
			eInfo2['playcount'] = 1 if playcount else 0
			eInfo2['mediatype'] = "episode"
			#eInfo2['userrating'] = eInfo2['rating']
			if 'EpisodeTitle' in eInfo2:
				#liz=xbmcgui.ListItem(DL+"[COLOR white]"+background+"x"+EPI(episode)+". "+eInfo2['EpisodeTitle']+"[/COLOR]")
				liz=xbmcgui.ListItem(DL+background+"x"+EPI(episode)+". "+eInfo2['EpisodeTitle'])
			else:
				liz=xbmcgui.ListItem(DL+background+"x"+EPI(episode)+". Episode "+EPI(episode))
			if ".jpg" in eInfo2['imagepi']:
				pass
				liz.setArt({"icon": eInfo2['imagepi'], "thumb": eInfo2['imagepi'], "poster": eInfo2['cover_url'], "banner": eInfo2['cover_url'], "fanart": eInfo2['backdrop_url'] })
			else:
				liz.setArt({"thumb": eInfo2['cover_url'], "poster": eInfo2['cover_url'], "banner": eInfo2['cover_url'], "fanart": eInfo2['backdrop_url'] })
			if "cast" in eInfo2:
				count = 0
				for value in eInfo2['cast']:
					for value2 in value:
						if 'thumbnail' in eInfo2['cast'][count]:
							eInfo2['cast'][count]['thumbnail']=eInfo2['cast'][count]['thumbnail'].replace("/original/","/w300/")
					count+=1
				liz.setCast(eInfo2['cast'])
			eInfo2.pop('cast', 1)
			eInfo2.pop('genre', 1)
			#eInfo2['genre'] = "b"
			#eInfo2['tagline'] = "a"
			liz.setInfo( "video", eInfo2 )
		else:
			#ST(1)
			liz=xbmcgui.ListItem(DL +""+name)
			#liz.setArt({"poster": metah['cover_url'], "banner": metah['cover_url'], "fanart": metah['backdrop_url'] })
			if "cast" in metah:
				liz.setCast(metah['cast'])
			metah.pop('cast', 1)
			if not 'mediatype' in metah:
				metah['mediatype'] = u'tvshow'
			metah['tagline'] = ""
			for i in metah['genre']:
				metah['tagline'] = i if metah['tagline'] == "" else metah['tagline'] + ", " + i
			#metah['tagline'] = i
			liz.setArt({"thumb": metah['cover_url'], "poster": metah['cover_url'], "banner": metah['cover_url'], "fanart": metah['backdrop_url'] })
			liz.setInfo("video", metah)
	else:
		liz = xbmcgui.ListItem(name)
		liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": info })
		liz.setArt({"poster": iconimage, "banner": logos, "fanart": logos })
		#listMode = 21 # Lists
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	items = []
	if mode == 1 or mode == 2:
		items = []
	elif mode == 96 and logos != "":
		liz.addContextMenuItems(items = [("Elementum", 'XBMC.RunPlugin(plugin://plugin.video.elementum/library/movie/play/{0}?play&doresume=true)'.format(logos)) ])
	elif mode == 303:
		liz.addContextMenuItems(items = [("Excluir da lista", 'XBMC.RunPlugin({0}?mode=305&logos={1})'.format(sys.argv[0], quote_plus(logos) ))])
	elif mode == 96:
		liz.addContextMenuItems(items = [("Excluir da lista", 'XBMC.RunPlugin({0}?url={1}&mode=355&iconimage={2}&name={3}&index={4})'.format(sys.argv[0], quote_plus(url), quote_plus(iconimage), quote_plus(name), index))])
	elif mode == 504 and info:
		liz.addContextMenuItems(items = [('Adicionar ao fav.', 'RunPlugin({0}?url={1}&mode=507&background={2}&info={3})'.format(sys.argv[0], quote_plus(url), quote_plus(background), quote_plus(info))  )])
	elif mode == 504:
		liz.addContextMenuItems(items = [('Remover dos fav.', 'RunPlugin({0}?url={1}&mode=511&index={2})'.format(sys.argv[0], quote_plus(url), index)  )])
	u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


# -*- coding: utf-8 -*-
import sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, hashlib, re, math, html
from urllib.parse import urlparse, quote_plus
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

AddonID = 'plugin.video.CubePlayMeta'
Addon = xbmcaddon.Addon(AddonID)
addonDir = Addon.getAddonInfo('path')
AddonName = Addon.getAddonInfo("name")
icon = os.path.join(addonDir,"icon.png")



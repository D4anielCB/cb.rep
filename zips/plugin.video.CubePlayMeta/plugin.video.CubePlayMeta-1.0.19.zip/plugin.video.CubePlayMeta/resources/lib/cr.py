# -*- coding: utf-8 -*-
import sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, hashlib, re, math, html, xbmcvfs
from urllib.parse import urlparse, quote_plus
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

import common

AddonID = 'plugin.video.CubePlayMeta'
Addon = xbmcaddon.Addon(AddonID)
addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
AddonName = Addon.getAddonInfo("name")

from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "0" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False
Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else None
crsession = Addon.getSetting("crsession") if Addon.getSetting("crsession") != "" else ""


def CRsession(req,session,force=False):
	import requests
	if force==True:
		try:
			url = 'https://api.crunchyroll.com/start_session.1.json'
			#headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100110 Firefox/11.0'}
			myobj = {'device_id': '35yuv973-KODI-nh6i-69l8-81m0p580id2j', 'device_type': 'com.crunchyroll.windows.desktop', 'access_token': 'LNDJgOit5yaRIWN'}
			x = requests.post(url, data = myobj)
			j=json.loads(x.text)
			Addon.setSetting("crsession", j['data']['session_id'])
			return CRsession(req,j['data']['session_id'],False)
		except:
			return "error"
	else:
		result = common.OpenURL(req+"&session_id="+session)
		resultj = json.loads(result)
		if resultj['error']:
			if 'bad_session' in resultj['code']:
				return CRsession(req,session,True)
			else:
				return resultj
			#return "erro"
		else:
			return resultj
			

# -----------------------------
def RemoveList(index):
	listFile = os.path.join(addon_data_dir, "crunchy.txt")
	chList = common.ReadList(listFile) 
	if index < 0 or index >= len(chList):
		return
	del chList[index]
	common.SaveList(listFile, chList)
	xbmc.executebuiltin("Container.Refresh()")
# -----------------------------
def Crunchy(): #530
	#import default
	#ST(sys.argv)
	#default.AddDir("Reload" , "", 40, isFolder=False)
	AddDir("Adicionar Anime" , "", 531, isFolder=False)
	file = os.path.join(addon_data_dir, "crunchy.txt")
	favList = common.ReadList(file)
	index = 0
	for ids in favList:
		try:
			mmm = mg.get_tvshow_details(title="",tmdb_id=str(ids['tmdb']), ignore_cache=MUcache, lang=MUlang)
			#ST(mmm)
			AddDir2(mmm[-1]['TVShowTitle'], str(ids['cr']), 532, "", "", info="", isFolder=True, background=mmm[-1]["tmdb_id"], metah=mmm[-1], index=index)
			
		except:
			pass
		index+=1

def PlayNextEpi(url,background,info,metah,episode): #535
	lista = CRsession("https://api.crunchyroll.com/list_media.0.json?series_id="+url+"&limit=200",crsession)
	meta = eval(metah)
	trak = traktS()
	E = 1
	for l in lista['data']:
		if info == l['collection_id']:
			play = "plugin://plugin.video.crunchyroll/?plotoutline=1&tvshowtitle=D&aired=2&episode_id="+l['media_id']+"&series_id=2&duration=1&collection_id=2&plot=.&episode=623251&thumb=g&title=D&fanart=g&premiered=2&mode=videoplay&playcount=0&status=Continuing&season=0&studio=T&genre=anime"
			pc = 1 if meta['imdbnumber']+str(meta['season_number'])+str(int(E)) in trak else None
			if pc == None:
				PlayUrl("", play, "", "", "", metah,background,str(E))
				break
				sys.exit()
			E+=1
	NF("Todos episódios assistidos")
			
def ListSeason(url,background): #532
	lista = CRsession("https://api.crunchyroll.com/list_collections.0.json?series_id="+url,crsession)
	#ST(lista)
	mmm = mg.get_tvshow_details(title="",tmdb_id=background, ignore_cache=MUcache, lang=MUlang)
	collection = []
	reseason = str(lista['data'])
	for l in lista['data']:
		#if not "'season': '1'" in str(lista['data']) and "'season': '0'" in reseason and not "Dub" in l['name']:
		if not "'season': '1'" in str(lista['data']) and "'season': '0'" in reseason and not "Dub" in l['name']:
			collection.append(["1", l['collection_id'], l['name'] ])
		elif not "Dub" in l['name']:
			collection.append([l['season'], l['collection_id'], l['name'] ])
			#collection[l['season']] = l['collection_id']
	#ST(collection)
	for s in collection:
		metasea=mergedicts(mmm[-1],mmm[int(s[0])])
		AddDir2("["+s[0]+"] "+s[2], url, 533, "", "", info=s[1], isFolder=True, background=s[0], metah=metasea)
	AddDir("---------- Autoplay ----------" , "", 40, isFolder=False)
	for s in collection:
		metasea=mergedicts(mmm[-1],mmm[int(s[0])])
		metasea['mediatype'] = "episode"
		#ST(metasea)
		AddDir2("["+s[0]+"] "+metasea['TVShowTitle'], url, 535, metasea['tmdb_id'], metasea['tmdb_id'], info=s[1], isFolder=False, IsPlayable=True, background=s[0], metah=metasea)
	AddDir("---------- Corrigir Temporada ----------" , "", 40, isFolder=False)
	for s in collection:
		metasea=mergedicts(mmm[-1],mmm[int(s[0])])
		AddDir2("["+s[0]+"] "+s[2], url, 536, "", "", info=s[1], isFolder=True, background=s[0], metah=metasea)

def ListEpi(url,background,info,metah): #533
	lista = CRsession("https://api.crunchyroll.com/list_media.0.json?series_id="+url+"&limit=200",crsession)
	meta = eval(metah)
	trak = traktS()
	prog = 1
	progress = xbmcgui.DialogProgress()
	progress.create('Carregando...')
	progress.update(0, "Carregando...")
	E = 1
	#ST()
	for l in lista['data']:
		if info == l['collection_id']:
			progtotal = int( 100*prog/( meta["episode_count"]) )
			progress.update(progtotal, "Só o primeiro acesso que demora\n"+str(progtotal)+" %")
			prog+=1
			if (progress.iscanceled()): break
			play = "plugin://plugin.video.crunchyroll/?plotoutline=1&tvshowtitle=D&aired=2&episode_id="+l['media_id']+"&series_id=2&duration=1&collection_id=2&plot=.&episode=623251&thumb=g&title=D&fanart=g&premiered=2&mode=videoplay&playcount=0&status=Continuing&season=0&studio=T&genre=anime"
			pc = 1 if meta['imdbnumber']+str(meta['season_number'])+str(int(E)) in trak else None
			AddDir2("" ,play, 3, "", "",  isFolder=False, IsPlayable=True, background=str(meta['season_number']), metah=meta, episode=str(E), playcount=pc)
			E+=1
			#except:
				#AddDir( "[COLOR]"+l["name"]+"[/COLOR] - "+str(l["episode_number"]) , "", 40, isFolder=False)
	progress.close()
	
def AddtoList(): #531
	#AddDir("Reload" , "", 40, isFolder=False)
	q = quote_plus(xbmcgui.Dialog().input("Digite o anime:") )
	google = common.OpenURL("https://www.google.com/search?q="+q+"+crunchyroll")
	googlere = re.compile("url\=http.+?crunchyroll.com\/.+?\/([^\&]+)").findall(google)
	try:
		if not "/" in googlere[0]:
			google = googlere[0]
		else:
			NF("Não encontrado")
			return
	except:
		google = ""
	crqj = CRsession("https://api.crunchyroll.com/autocomplete.0.json?media_types=anime&q="+q,crsession)
	croption1 = []
	croption2 = []
	if not crqj['data']:
		crqj = CRsession("https://api.crunchyroll.com/autocomplete.0.json?media_types=anime&q="+google,crsession)
	if not crqj['data']:
		NF("Não encontrado!")
		return
	for x in crqj['data']:
		croption1.append(x['series_id'])
		croption2.append(x['name'])
	d = xbmcgui.Dialog().select("Escolha o anime no Crunchyroll:", croption2)
	if d==-1: return
	tmid = common.OpenURL("https://api.themoviedb.org/3/search/tv?api_key=bd6af17904b638d482df1a924f1eabb4&language=en&query="+quote_plus(crqj['data'][d]['name']))
	tmdij = json.loads(tmid)
	tmdboption1 = []
	tmdboption2 = []
	#tmdij = {"page":1,"results":[{"backdrop_path":"/3ILMlmC30QUnYkY3XEBOyJ82Dqu.jpg","first_air_date":"2016-04-03","genre_ids":[10765,10759,35,16],"id":65930,"name":"Boku no Hero Academia","origin_country":["JP"],"original_language":"ja","original_name":"","overview":"Devido a um fenómeno desconhecido, cerca de 80% da população possui \"Singularidades”, isto é, super-poderes. No entanto, a existência deste poderes levou a um aumento exponencial da taxa de criminalidade e obrigou os mais corajosos a entra em acção, utilizando os seus poderes para o bem e tornando-se super-heróis. Desde pequeno, Midoriya Izuku sonhava ser um destes super-heróis e seguir as pisadas do seu ídolo, All Might. Contudo, ainda muito jovem, Izuku descobre que não possui uma Singularidade e que, por isso, não poderá ser um herói. Não deixando que isso o impeça, Izuku está determinado a entrar em Yuuei, a melhor escola de super-heróis do Japão, apesar de ninguém o levar a sério. Mas poderá um fatídico encontro com o seu grande ídolo mudar o seu destino?","popularity":89.365,"poster_path":"/mWHCII5OWHx5pRSN2VYYLvT8DbB.jpg","vote_average":8.9,"vote_count":2690}],"total_pages":1,"total_results":1}
	for x in tmdij["results"]:
		tmdboption1.append(x['id'])
		try:
			tmdboption2.append(x['name']+ " ("+ x["first_air_date"][2]+x["first_air_date"][3]+")")
		except:
			tmdboption2.append(x['name'])
	d2 = xbmcgui.Dialog().select("Escolha o anime no tmdb:", tmdboption2)
	if d2==-1: return
	SaveFile(croption1[d],tmdboption1[d2],"crunchy")
	xbmc.executebuiltin("Container.Refresh()")
	
def SaveFile(cr, tmdb,  file):
	file = os.path.join(addon_data_dir, file+".txt")
	favList = common.ReadList(file)
	for item in favList:
		if item["tmdb"] == str(tmdb):
			NF("Anime já adicionado")
			return
	chList = []	
	for channel in chList:
		if channel["tmdb"] == tmdb:
			tmdb = channel["tmdb"]
			cr = channel["cr"]
			break
	data = {"cr": cr, "tmdb": str(tmdb)}
	favList.append(data)
	common.SaveList(file, favList)
	NF("Anime Adicionado a lista")
# --------------------------------------
def AddDir(name, url, mode, iconimage='', logos='', index="", move=0, isFolder=True, IsPlayable=False, background=None, cacheMin='0', info='', DL='', year='', metah={}, episode='', playcount=None):
	urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'cache': cacheMin, 'index': index, 'info': info, 'background': background, 'DL': DL, 'year': year, 'metah': metah, 'episode': episode, 'playcount': playcount}
	if metah:
		if background and episode:
			mg = metahandlers.MetaData()
			#sInfo = mg.get_seasons(metah['TVShowTitle'], metah['imdbnumber'], [1])
			eInfo = mg.get_episode_meta(metah['TVShowTitle'], metah['imdbnumber'], SEAS(background), EPI(episode))
			#liz=xbmcgui.ListItem(DL+background+"."+EPI(episode)+" "+eInfo['title'] +" "+Data(eInfo['premiered'])+ " [COLOR blue]["+str(eInfo['rating'])+"][/COLOR]", iconImage=metah['cover_url'], thumbnailImage=metah['cover_url'])
			liz=xbmcgui.ListItem(DL+background+"x"+EPI(episode)+". "+eInfo['title'], iconImage=metah['cover_url'], thumbnailImage=metah['cover_url'])
			#liz.setRating("imdb", 0.1, 8940, False)
			liz.setArt({"thumb": eInfo['cover_url'], "poster": eInfo['cover_url'], "banner": eInfo['cover_url'], "fanart": eInfo['backdrop_url'] })
			infoLabels = metah
			eInfo['userrating'] = eInfo['rating']
			eInfo['mediatype'] = u'movie'
			#ST(eInfo)
			if playcount:
				eInfo['playcount'] = playcount
			else:
				eInfo.pop('playcount', 1)
			liz.setInfo( "video",  eInfo )
		else:
			metah['mediatype'] = u'tvshow'
			metah['Imdbnumber'] = metah['imdbnumber']
			if playcount:
				metah['playcount'] = playcount
			else:
				metah.pop('playcount', 1)
			liz=xbmcgui.ListItem(DL +""+name)
			liz.setArt({"poster": metah['art']['poster'], "banner": metah['art']['poster'], "fanart": metah['art']['fanart'] })
			count=0
			if "cast" in metah:
				count = 0
				for value in metah['cast']:
					for value2 in value:
						if 'thumbnail' in metah['cast'][count]:
							metah['cast'][count]['thumbnail']=metah['cast'][count]['thumbnail'].replace("/original/","/w300/")
					count+=1
				liz.setCast(metah['cast'])
			metah.pop('cast', 1)
			metah.pop('castandrole', 1)
			metah.pop('art', 1)
			liz.setInfo( "video", metah )
	else:
		liz = xbmcgui.ListItem(name ,iconimage, iconimage)
		liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": info, "Imdbnumber": "tt0460681" })
		liz.setArt({"poster": iconimage, "banner": logos, "fanart": logos, "icon":  iconimage})
		#listMode = 21 # Lists
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	items = []
	if mode == 1 or mode == 2:
		items = []
	elif mode == 96 and logos != "":
		liz.addContextMenuItems(items = [("Elementum", 'XBMC.RunPlugin(plugin://plugin.video.elementum/library/movie/play/{0}?play&doresume=true)'.format(logos)) ])
	elif mode == 303:
		liz.addContextMenuItems(items = [("Excluir da lista", 'XBMC.RunPlugin({0}?mode=305&logos={1})'.format(sys.argv[0], quote_plus(logos) ))])
	elif mode == 96:
		liz.addContextMenuItems(items = [("Excluir da lista", 'XBMC.RunPlugin({0}?url={1}&mode=355&iconimage={2}&name={3}&index={4})'.format(sys.argv[0], quote_plus(url), quote_plus(iconimage), quote_plus(name), index))])
	if mode == 10:
		urlParams['index'] = index
	u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
# --------------------------------------
def AddDir2(name, url, mode, iconimage='', logos='', index="", move=0, isFolder=True, IsPlayable=False, background=None, cacheMin='0', info='', DL='', year='', metah={}, episode='', playcount=None): #add2
	urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'cache': cacheMin, 'index': index, 'info': info, 'background': background, 'DL': DL, 'year': year, 'metah': metah, 'episode': episode, 'playcount': playcount}
	#ST(iconimage)
	if metah:
		if background and episode:
			eInfo = mg.get_episode_details(metah['tmdb_id'], SEAS(background), EPI(episode), ignore_cache=MUcacheEpi, lang=MUlang)
			eInfo2 = mergedicts(metah,eInfo)
			#eInfo2['imagepi'] = eInfo2['imagepi'].replace("/original/","/w780/")
			#eInfo2['cover_url'] = eInfo2['cover_url'].replace("/original/","/w500/")
			#eInfo2['backdrop_url'] = eInfo2['backdrop_url'].replace("/original/","/w780/")
			eInfo2['playcount'] = 1 if playcount else 0
			eInfo2['mediatype'] = "episode"
			#eInfo2['userrating'] = eInfo2['rating']
			if 'EpisodeTitle' in eInfo2:
				#liz=xbmcgui.ListItem(DL+"[COLOR white]"+background+"x"+EPI(episode)+". "+eInfo2['EpisodeTitle']+"[/COLOR]")
				liz=xbmcgui.ListItem(DL+background+"x"+EPI(episode)+". "+eInfo2['EpisodeTitle'])
			else:
				liz=xbmcgui.ListItem(DL+background+"x"+EPI(episode)+". Episode "+EPI(episode))
			if ".jpg" in eInfo2['imagepi']:
				liz.setArt({"icon": eInfo2['imagepi'], "thumb": eInfo2['imagepi'], "poster": eInfo2['cover_url'], "banner": eInfo2['cover_url'], "fanart": eInfo2['backdrop_url'] })
			else:
				liz.setArt({"thumb": eInfo2['cover_url'], "poster": eInfo2['cover_url'], "banner": eInfo2['cover_url'], "fanart": eInfo2['backdrop_url'] })
			if "cast" in eInfo2:
				count = 0
				for value in eInfo2['cast']:
					for value2 in value:
						if 'thumbnail' in eInfo2['cast'][count]:
							eInfo2['cast'][count]['thumbnail']=eInfo2['cast'][count]['thumbnail'].replace("/original/","/w300/")
					count+=1
				liz.setCast(eInfo2['cast'])
			eInfo2.pop('cast', 1)
			eInfo2.pop('genre', 1)
			#eInfo2['genre'] = "b"
			#eInfo2['tagline'] = "a"
			liz.setInfo( "video", eInfo2 )
		else:
			liz=xbmcgui.ListItem(DL +""+name)
			#liz.setArt({"poster": metah['cover_url'], "banner": metah['cover_url'], "fanart": metah['backdrop_url'] })
			if "cast" in metah:
				liz.setCast(metah['cast'])
			metah.pop('cast', 1)
			if not 'mediatype' in metah:
				metah['mediatype'] = u'tvshow'
			metah['tagline'] = ""
			for i in metah['genre']:
				metah['tagline'] = i if metah['tagline'] == "" else metah['tagline'] + ", " + i
			#metah['tagline'] = i
			liz.setArt({"thumb": metah['cover_url'], "poster": metah['cover_url'], "banner": metah['cover_url'], "fanart": metah['backdrop_url'] })
			liz.setInfo("video", metah)
	else:
		liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage )
		liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": info })
		liz.setArt({"poster": iconimage, "banner": logos, "fanart": logos })
		#listMode = 21 # Lists
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	items = []
	if mode == 1 or mode == 2:
		items = []
	elif mode == 96 and logos != "":
		liz.addContextMenuItems(items = [("Elementum", 'RunPlugin(plugin://plugin.video.elementum/library/movie/play/{0}?play&doresume=true)'.format(logos)) ])
	elif mode == 303:
		liz.addContextMenuItems(items = [("Excluir da lista", 'RunPlugin({0}?mode=305&logos={1})'.format(sys.argv[0], quote_plus(logos) ))])
	elif mode == 96:
		liz.addContextMenuItems(items = [("Excluir da lista", 'RunPlugin({0}?url={1}&mode=355&iconimage={2}&name={3}&index={4})'.format(sys.argv[0], quote_plus(url), quote_plus(iconimage), quote_plus(name), index))])
	elif mode == 532:
		liz.addContextMenuItems(items = [( 'Excluir Anime' , 'RunPlugin('+sys.argv[0]+'?url={1}&mode=534&index='+str(index)+')')])
	#elif mode == 533 or mode == 535:
		#liz.addContextMenuItems(items = [( 'Corrigir Temporada' , 'RunPlugin('+sys.argv[0]+'?url='+quote_plus(url)+'&mode=536&info='+info+'&metah='+quote_plus(json.dumps(metah))+')')])
	if mode == 10:
		urlParams['index'] = index
	u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
#----------------------------------------
def CorrigirTemp(name,url,background,info,metah): #536
	#AddDir("Reload" , "", 40, isFolder=False)
	meta = eval(metah)
	mmm = mg.get_tvshow_details(title="",tmdb_id=meta['tmdb_id'], ignore_cache=MUcache, lang=MUlang)
	cor = []	
	cor2 = []	
	for s in mmm:
		if 'name' in mmm[s]:
			cor.append(mmm[s]['name'])
			cor2.append(str(s))
	d = xbmcgui.Dialog().select("Escolha o temporada correta: "+name, cor)
	if d == -1: return
	lista = CRsession("https://api.crunchyroll.com/list_collections.0.json?series_id="+url,crsession)
	tempcorreta=cor2[d]
	#ST(cor2[d])
	#mmm = mg.get_tvshow_details(title="",tmdb_id=background, ignore_cache=MUcache, lang=MUlang)
	collection = []
	reseason = str(lista['data'])
	for l in lista['data']:
		#if not "'season': '1'" in str(lista['data']) and "'season': '0'" in reseason and not "Dub" in l['name']:
		if info == l['collection_id']:
			collection.append(["1", l['collection_id'], l['name'] ])
	#ST(collection)
	for s in collection:
		metasea=mergedicts(mmm[-1],mmm[int(tempcorreta)])
		AddDir2("["+tempcorreta+"] "+s[2], url, 533, "", "", info=s[1], isFolder=True, background=tempcorreta, metah=metasea)
	AddDir("---------- Autoplay ----------" , "", 40, isFolder=False)
	for s in collection:
		metasea=mergedicts(mmm[-1],mmm[int(tempcorreta)])
		metasea['mediatype'] = "episode"
		#ST(metasea)
		AddDir2("["+tempcorreta+"] "+metasea['TVShowTitle'], url, 535, metasea['tmdb_id'], metasea['tmdb_id'], info=s[1], isFolder=False, IsPlayable=True, background=tempcorreta, metah=metasea)
#----------------------------------------
def traktS():
	if not Ctrakt:
		return []
	try:
		headers1 = {'Content-Type': 'application/json','trakt-api-version': '2','trakt-api-key': '888a9d79a643b0f4e9f58b5d4c2b13ee6d8bd584bc72bff8b263f184e9b5ed5d'}
		response_body = common.OpenURL('https://api.trakt.tv/users/'+Ctrakt+'/watched/shows',headers=headers1)
		j=json.loads(response_body)
		trak=[]
	except:
		return []
	for m in j:
		try:
			for Sea in m['seasons']:
				for epi in Sea['episodes']:
					trak.append(m['show']['ids']['imdb']+str(Sea['number'])+str(epi['number']))
		except:
			pass
	return trak	
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		try:
			y = str(x)
		except:
			y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
#----------------------------------------
def PlayUrl(name, url, iconimage=None, info='', sub='', metah='', background='', episode=''):
	xbmc.log('--- Playing "{0}". {1}'.format(name, url), 2)
	listitem = xbmcgui.ListItem(path=url)
	if metah:
		try:
			metah2 = eval(metah)
			eInfo_ = mg.get_episode_details(metah2['tmdb_id'], SEAS(background), EPI(episode))
			eInfo = mergedicts(metah2,eInfo_)
			eInfo["Title"]= eInfo['EpisodeTitle']
			S=str(eInfo['season'])
			E=str(eInfo['episode'])
			if MUfanArt:
				try:
					fanart = common.OpenURL("http://webservice.fanart.tv/v3/tv/"+eInfo['tvdb_id']+"?api_key=f8ba25de3d50ea5655f5b6bd78387878")
					fanartj = json.loads(fanart)
					clearlogo = fanartj["hdtvlogo"][1]['url']
				except:
					clearlogo=""
			listitem.setArt({"poster": eInfo['cover_url'], "banner": eInfo['cover_url'], "fanart": eInfo['backdrop_url'], "clearlogo": clearlogo })
			eInfo.pop('cast', 1)
			try:
				eInfo['plot'] += u"\n[COLOR button_focus]Exibição:[/COLOR] " +Data(str(eInfo['premiered'])) if MUlang == "pt-BR" else "\nAired: " +Data(str(eInfo['premiered']))
			except:
				pass
			eInfo['mediatype'] = "episode"
			listitem.setInfo( "video",  eInfo )
		except:
			try:
				metah2 = eval(metah)
				metah2['Title'] = metah2['TVShowTitle']
				metah2['season'] = int(background)
				metah2['episode'] = int(episode)
				metah2['mediatype'] = "episode"
				listitem.setInfo( "video", metah2 )
			except:
				pass
		try:
			ids = json.dumps({u'tmdb': metah2['tmdb_id']})
			xbmcgui.Window(10000).setProperty('script.trakt.ids', ids)
		except:
			pass
	else:
		listitem.setInfo("Video", {"mediatype": "video", "Title": name, "Plot": info })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
def mergedicts(x, y):
    """Given two dicts, merge them into a new dict as a shallow copy."""
    z = x.copy()
    z.update(y)
    return z
def EPI(x):
	x = re.sub('[0]+(\d+)', r'\1', x )
	return str(x)
def SEAS(x):
	x = re.sub('0(\d)', r'\1', x )
	return str(x)
	
def NF(x, t=5000):
	xbmc.executebuiltin("Notification({0}, {1}, {3}, {2})".format(AddonName, str(x), icon, t))

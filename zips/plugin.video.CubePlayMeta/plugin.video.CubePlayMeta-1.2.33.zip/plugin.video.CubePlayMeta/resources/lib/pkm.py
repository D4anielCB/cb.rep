# -*- coding: utf-8 -*-
import xbmc
#dbID = xbmc.getInfoLabel('ListItem.DBID')
#dbType = xbmc.getInfoLabel('ListItem.DBTYPE')
#filePath = xbmc.getInfoLabel('ListItem.FolderPath')
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse
from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

AddonID = 'plugin.video.CubePlayMeta'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import common, xx

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
if not os.path.exists(cacheDir):
	os.makedirs(cacheDir)

cFonte1 = Addon.getSetting("cFonte1")
cFonte2 = Addon.getSetting("cFonte2")
cFonte3 = Addon.getSetting("cFonte3")

cTxt1 = Addon.getSetting("cTxt1")
cTxt2 = Addon.getSetting("cTxt2")
cTxt3 = Addon.getSetting("cTxt3")

DirM = Addon.getSetting("cDir")
DirB = Addon.getSetting("cDirB")
CEle = Addon.getSetting("cEle")

DirCount = Addon.getSetting("DirCount") if Addon.getSetting("DirCount") != "" else 0

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "0" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False

Cat = Addon.getSetting("Cat") if Addon.getSetting("Cat") != "" else 0
Cat2 = Addon.getSetting("Cat2") if Addon.getSetting("Cat2") != "" else "0"
Cidi = Addon.getSetting("Cidi") if Addon.getSetting("Cidi") != "" else "0"

Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else ""
CtraktAuth = Addon.getSetting("CtraktAuth") if Addon.getSetting("CtraktAuth") != "" else ""
CTraktResume = True if Addon.getSetting("CTraktResume") == "true" else False

Clista=["Sem filtro (Mostrar Todos)","Ação", "Animação", "Aventura", "Crime", "Comédia", "Documentário", "Drama", "Fantasia", "Ficção científica", "Mistério", "Romance", "Terror", 'Thriller']
CImdb=["nome","ano","vote"]
CImdb2=["Nome","Ano","Rating"]

#-----------------------------------------
params =  urllib.parse.parse_qs( sys.argv[2][1:] ) 
url = params.get('url',[None])[0]
logos = params.get('logos',[None])[0]
name = params.get('name',[None])[0]
iconimage = params.get('iconimage',[None])[0]
cache = int(params.get('cache', '0')[0]) if params.get('cache') else 0
index = int(params.get('index', '-1')[0]) if params.get('index') else -1
move = int(params.get('move', '0')[0]) if params.get('move') else 0
mode = int(params.get('mode', '0')[0]) if params.get('mode') else 0
info = params.get('info',[None])[0]
background = params.get('background',[None])[0]
DL = params.get('DL',[None])[0]
year = params.get('year',[None])[0]
metah = params.get('metah',[None])[0]
episode = params.get('episode',[None])[0]
playcount = params.get('playcount',[None])[0]
# --------------  Trakt
def otto(): #600
	mmm = mg.get_tvshow_details(title="",tmdb_id="220150", ignore_cache=MUcache, lang=MUlang)
	site = common.OpenURL("https://ottofansub.blogspot.com/2023/04/pokemon-horizons-series.html")
	lista = re.compile("href=\"(.{1,10}anonfiles[^\"]+)").findall(site)
	#ST(mmm)
	i = 1
	pc = None
	trak = xx.traktS()
	metasea=xx.mergedicts(mmm[-1],  mmm[ 1 ] )
	for ids in lista:
		pc = 1 if mmm[-1]['imdbnumber']+"1"+str(i) in trak else None
		#mmm = mg.get_tvshow_details(title="",tmdb_id=ids["tmdb"], ignore_cache=MUcache, lang=MUlang)
		
		#ST(metasea)
		#xx.AddDir2("["+ids["season"]+"] "+mmm[-1]["TVShowTitle"], ids["cr"], 535, "", "crunchyfav", info=ids["col_id"], isFolder=False, IsPlayable=True, background=ids["season"], metah=metasea, index=i)
		#xx.AddDir2("["+ids["season"]+"] "+mmm[-1]["TVShowTitle"], ids["erai"], 523, "erai", metasea["tmdb_id"], info="", isFolder=True, background=ids["season"], metah=metasea, index=i)
		xx.AddDir2("" ,ids, 601, "", "",  isFolder=False, IsPlayable=True, background="1", metah=mmm[-1], episode=str(i), playcount=pc, DL="")
		i+=1
	#xx.AddDir2("1", 1, 601, "erai", "", info="", isFolder=True, background="", metah="", index=0)
def playotto(): #601
	site = common.OpenURL(url)
	lista = re.compile("href=\"(.{80,150}[^\"]+mp4)").findall(site)
	mp4 = re.sub('https', 'http', lista[0] )
	#ST(iconimage)
	xx.PlayUrl("", mp4 + "|referer=https://anonfiles.com&User-Agent=Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100110 Firefox/11.0", iconimage, epi=episode)
def pokemothim(): #602
	pc = None
	trak = xx.traktS()
	mmm = mg.get_tvshow_details(title="",tmdb_id="220150", ignore_cache=MUcache, lang=MUlang)
	site = common.OpenURL("https://www.pokemothim.net/2023/04/pokemon-horizontes.html?m=1")
	lista = re.compile("<a href=.https:.+?\/video\/(.+?). target=._blank.>HZ (\d+)").findall(site)
	last = re.compile("src=.+?dailymotion.com\/embed\/video\/([^\"]+)").findall(site)
	#ST(last)
	metasea=xx.mergedicts(mmm[-1],  mmm[ 1 ] )
	for url2,ids in lista:
		pc = 1 if mmm[-1]['imdbnumber']+"1"+str(int(ids)) in trak else None
		xx.AddDir2("" ,url2, 603, "", "",  isFolder=False, IsPlayable=True, background="1", metah=mmm[-1], episode=ids, playcount=pc, DL="")
		idlast = int(ids)
	pc = 1 if mmm[-1]['imdbnumber']+"1"+str(idlast+1) in trak else None
	xx.AddDir2("" ,last[0], 603, "", "",  isFolder=False, IsPlayable=True, background="1", metah=mmm[-1], episode=str(idlast+1), playcount=pc, DL="")
def playpokemothim(): #603
	#ST(url)
	xx.PlayUrl("", "plugin://plugin.video.dailymotion_com/?url="+url+"&mode=playVideo", iconimage, epi=episode)
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		try:
			y = str(x)
		except:
			y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
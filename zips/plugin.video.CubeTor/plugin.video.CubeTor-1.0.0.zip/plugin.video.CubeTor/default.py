# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse


AddonID = 'plugin.video.CubeTor'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import xx
import comando

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")

if not os.path.exists(cacheDir):
	os.makedirs(cacheDir)

def Categories(): #0
	xx.AddDir("Mais Baixados", "", "comando.MaisBaixados", isFolder=True)
	xx.AddDir("Dublados", "", "comando.Dublado", isFolder=True)
	xx.AddDir("Filmes", "", "comando.Filmes", isFolder=True)
	
params = urllib.parse.parse_qs(sys.argv[2][1:]) 
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]

if mode == None:
	Categories()
	xx.setViewM()
if mode == "comando.Dublado":
	comando.Torrents("https://comandotorrents.org/category/dublado/")
	xx.setViewM2()
if mode == "comando.Filmes":
	comando.Torrents("https://comandotorrents.org/category/filmes/")
	xx.setViewM2()
if mode == "comando.MaisBaixados":
	comando.Torrents("https://comandotorrents.org/category/filmes-mais-baixados/")
	xx.setViewM2()
if mode == "comando.ListTorrents":
	comando.ListTorrents()
	xx.setViewM2()
if mode == "comando.PlayTorrents":
	comando.PlayTorrents()
elif mode == "PlayUrl":
	xx.PlayUrl(name, url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
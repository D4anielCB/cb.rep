# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

AddonID = 'plugin.video.CubeTor'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import xx

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "1" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False
Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else None

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
#-----------------------------------------
params = urllib.parse.parse_qs(sys.argv[2][1:])
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]
#-----------------------------------------
cPagetmdb = "0" if Addon.getSetting("cPagetmdb")=="" else Addon.getSetting("cPagetmdb") #paginacao Filmes
cPagetmdbgenero = "0" if Addon.getSetting("cPagetmdbgenero")=="" else Addon.getSetting("cPagetmdbgenero") #paginacao Genero
tmdbgenero = {"0": "Sem Filtro", "28": "Ação", "16":"Animação", "12":"Aventura", "35":"Comédia", "80":"Crime", "99":"Documentário", "18":"Drama", "10751":"Família", "14":"Fantasia", "27":"Horror", "878":"Sci-fi", "53":"Thriller"}
#-----------------------------------------
def Genero():
	gen = []
	gen2 = []
	for entry in tmdbgenero:
		gen.append(tmdbgenero[entry])
		gen2.append(entry)
	d = xbmcgui.Dialog().select("Selecione o gênero", gen)
	if d >-1:
		Addon.setSetting(url, gen2[d] )
		xbmc.executebuiltin("Container.Refresh()")	
#-----------------------------------------
def ListMovies():
	xx.AddDir("[COLOR white][B]Gênero:[/B] "+tmdbgenero[cPagetmdbgenero]+" [/COLOR]", "cPagetmdbgenero" , "tmdb.Genero" ,"", isFolder=False, dados={})
	if int(cPagetmdb) > 0:
		xx.AddDir("[COLOR blue][B]<< Pagina Anterior ["+ str( int(cPagetmdb) ) +"[/B]][/COLOR]", cPagetmdb , "xx.PaginacaoMenos" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Previous-icon.png", isFolder=False, dados={'page': 'cPagetmdb'})
	xx.AddDir("[COLOR blue][B]Proxima Pagina >>  ["+ str( int(cPagetmdb) + 1 ) +"[/B]][/COLOR]", cPagetmdb , "xx.PaginacaoMais" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Next-2-2-icon.png", isFolder=False, dados={'page': 'cPagetmdb'})
	l = int(cPagetmdb) * 4
	progress = xbmcgui.DialogProgress()
	progress.create('Carregando...')
	progress.update(0, "Carregando...")
	prog = 1
	for page in range (1,5):
		if cPagetmdbgenero == "0":
			link = xx.OpenURL('https://api.themoviedb.org/3/discover/movie?api_key=bd6af17904b638d482df1a924f1eabb4&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page='+str(page+l)+'&with_watch_monetization_types=flatrate&year=2021')
		else:
			link = xx.OpenURL('https://api.themoviedb.org/3/discover/movie?api_key=bd6af17904b638d482df1a924f1eabb4&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page='+str(page+l)+'&with_watch_monetization_types=flatrate&year=2021&with_genres='+cPagetmdbgenero)
		entries=json.loads(link)
		for entry in entries['results']:
			if (progress.iscanceled()): break
			progtotal = int( 100*prog/len(entries['results'])/4 )
			progress.update(progtotal, str(progtotal)+" %")
			prog+=1
			mm = mg.get_tmdb_details(tmdb_id=str(entry['id']), imdb_id="", tvdb_id="", title="", year="", media_type="movies", preftype="", manual_select=False, ignore_cache=False)
			#ST(mm)
			xx.AddDir(str(entry['id']), "plugin://plugin.video.elementum/library/movie/play/"+str(entry['id'])+"?doresume=true", "PlayUrl", isFolder=False, IsPlayable=True, dados={'mmeta': mm})
	progress.close()
#----------------------------------------
def CategoryOrdem(x):
	x2 = Addon.getSetting(eval("x"))
	name2 = "Data" if x2=="0" else "Título"
	AddDir("[COLOR green][B][Organizado por:][/B] "+name2 +" (Clique para alterar)[/COLOR]" , x, "", "https://lh5.ggpht.com/gv992ET6R_InCoMXXwIbdRLJczqOHFfLxIeY-bN2nFq0r8MDe-y-cF2aWq6Qy9P_K-4=w300", "https://lh5.ggpht.com/gv992ET6R_InCoMXXwIbdRLJczqOHFfLxIeY-bN2nFq0r8MDe-y-cF2aWq6Qy9P_K-4=w300", isFolder=False)
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]) or type(x) == type(set([''])):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
#-----------------------------------------

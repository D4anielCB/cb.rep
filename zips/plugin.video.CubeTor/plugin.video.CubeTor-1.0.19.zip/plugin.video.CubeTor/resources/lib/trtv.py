# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

AddonID = 'plugin.video.CubeTor'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import xx

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "1" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False
Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else None
cDirtrtv = Addon.getSetting("cDirtrtv") if Addon.getSetting("cDirtrtv") != "" else None

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
#-----------------------------------------
params = urllib.parse.parse_qs(sys.argv[2][1:])
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]
#-----------------------------------------
def Categories():
	xx.AddDir("Episodes", "", "trtv.Episodes", isFolder=True)
	xx.AddDir("Filmes", "", "trtv.Movies", isFolder=True)
def Episodes():
	trak = xx.traktS()
	ShowDir = os.path.join( cDirtrtv, "Shows")
	entries = os.listdir(ShowDir)
	for entry in entries:
		if ".mp4" in entry:
			tmdb = re.compile("\d+").findall(entry)
			SeaEpi = re.compile("Season.?(\d+).+?Epis.+?(\d+)").findall(entry)
			meta = mg.get_tvshow_details(title="", tmdb_id=tmdb[0], ignore_cache=MUcache, lang=MUlang)
			meta['mediatype'] = "episode"
			pc = 1 if tmdb[0]+SeaEpi[0][0]+SeaEpi[0][1] in trak else None
			try:
				play = os.path.join( ShowDir, entry)
				xx.AddDir(meta[-1]["TVShowTitle"], play, "PlayUrl", isFolder=False, IsPlayable=True, dados={'meta': meta[-1], 'season': SeaEpi[0][0], 'episode': SeaEpi[0][1], 'pc': pc})
			except:
				pass
def Movies():
	MovieDir = os.path.join( cDirtrtv, "Movies")
	entries = os.listdir(MovieDir)
	for entry in entries:
		if ".mp4" in entry:
			tmdb = re.compile("\d+").findall(entry)
			play = os.path.join( MovieDir, entry)
			try:
				mm = mg.get_tmdb_details(tmdb_id=tmdb[0], imdb_id="", tvdb_id="", title="", year="", media_type="movies", preftype="", manual_select=False, ignore_cache=False)
				xx.AddDir(entry, play, "PlayUrl", isFolder=False, IsPlayable=True, dados={'mmeta': mm})
			except:
				pass
			#xx.AddDir(mm['title'], "plugin://plugin.video.elementum/play?uri="+entry['magnet']+"&doresume=true&type=movie"+entry['imdb'], "PlayUrl", isFolder=False, IsPlayable=True, dados={'mmeta': mm})
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]) or type(x) == type(set([''])):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
#-----------------------------------------

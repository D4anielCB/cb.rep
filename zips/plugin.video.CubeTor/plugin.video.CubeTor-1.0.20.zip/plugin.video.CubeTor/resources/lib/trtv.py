# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

from metadatautils import MetadataUtils
mg = MetadataUtils()
mg.tmdb.api_key = 'bd6af17904b638d482df1a924f1eabb4'

AddonID = 'plugin.video.CubeTor'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import xx

MUlang = "pt-BR" if Addon.getSetting("MUlang") == "1" else "en"
MUcache = True if Addon.getSetting("MUcache") == "true" else False
MUcacheEpi = True if Addon.getSetting("MUcacheEpi") == "true" else False
MUfanArt = True if Addon.getSetting("MUfanArt") == "true" else False
Ctrakt = Addon.getSetting("Ctrakt") if Addon.getSetting("Ctrakt") != "" else None
cDirtrtv = Addon.getSetting("cDirtrtv") if Addon.getSetting("cDirtrtv") != "" else None

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
#-----------------------------------------
params = urllib.parse.parse_qs(sys.argv[2][1:])
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]
#-----------------------------------------
def Categories():
	#xx.AddDir("Episodes", "", "trtv.Episodes", isFolder=True)
	xx.AddDir("Series", "", "trtv.Series", isFolder=True)
	xx.AddDir("Filmes", "", "trtv.Movies", isFolder=True)
def Series():
	xx.AddDir("Reload", "", "Reload", isFolder=False, IsPlayable=False)
	trak = xx.traktS()
	ShowDir = xx.OpenURL(cDirtrtv+"/Shows")
	entries = re.findall('(\d+)\%20[^\"|\']+mp4', ShowDir)
	entries = list(dict.fromkeys(entries))
	for entry in entries:
		meta = mg.get_tvshow_details(title="", tmdb_id=entry, ignore_cache=MUcache, lang=MUlang)
		xx.AddDir(meta[-1]["TVShowTitle"], entry, "trtv.Episodes", isFolder=True, dados={'meta': meta[-1]})
def Episodes():
	xx.AddDir("Reload", "", "Reload", isFolder=False, IsPlayable=False)
	trak = xx.traktS()
	ShowDir = xx.OpenURL(cDirtrtv+"/Shows")
	entries = re.findall('[^\"|\']+mp4', ShowDir)
	for entry in entries:
		if not " " in entry and url in entry:
			file = unquote(entry)
			tmdb = re.compile("\d+").findall(file)
			SeaEpi = re.compile("Season.?(\d+).+?Epis.+?(\d+)").findall(file)
			meta = mg.get_tvshow_details(title="", tmdb_id=tmdb[0], ignore_cache=MUcache, lang=MUlang)
			meta['mediatype'] = "episode"
			pc = 1 if tmdb[0]+SeaEpi[0][0]+SeaEpi[0][1] in trak else None
			try:
				play = cDirtrtv+"/Shows/"+entry
				#play = "https://s0.blogspotting.art/web-sources/8C49366FDF6C9762/1575177/file|referer=http://trailers.to"
				xx.AddDir(meta[-1]["TVShowTitle"], play, "PlayUrl", isFolder=False, IsPlayable=True, dados={'meta': meta[-1], 'season': SeaEpi[0][0], 'episode': SeaEpi[0][1], 'pc': pc})
			except:
				pass
def Movies():
	xx.AddDir("Reload", "", "Reload", isFolder=False, IsPlayable=False)
	MovieDir = xx.OpenURL(cDirtrtv+"/Movies")
	entries = entries = re.findall('[^\"|\']+mp4', MovieDir)
	ST(entries)
	for entry in entries:
		if not " " in entry:
			file = unquote(entry)
			tmdb = re.compile("\d+").findall(file)
			play = cDirtrtv+"/Movies/"+entry
			try:
				mm = mg.get_tmdb_details(tmdb_id=tmdb[0], imdb_id="", tvdb_id="", title="", year="", media_type="movies", preftype="", manual_select=False, ignore_cache=False)
				xx.AddDir(file, play, "PlayUrl", isFolder=False, IsPlayable=True, dados={'mmeta': mm})
			except:
				pass
			#xx.AddDir(mm['title'], "plugin://plugin.video.elementum/play?uri="+entry['magnet']+"&doresume=true&type=movie"+entry['imdb'], "PlayUrl", isFolder=False, IsPlayable=True, dados={'mmeta': mm})
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]) or type(x) == type(set([''])):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
#-----------------------------------------

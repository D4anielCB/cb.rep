# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

AddonID = 'plugin.video.CubeTor'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
#import common

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")
#-----------------------------------------
params = urllib.parse.parse_qs(sys.argv[2][1:]) 
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]
#-----------------------------------------
def PlayUrl(name, url): #1
	xbmc.log('--- Playing "{0}". {1}'.format(name, url), 2)
	listitem = xbmcgui.ListItem(path=url)
	listitem.setMimeType('video/mp2t')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
#-----------------------------------------
def AddDir(name, url, mode, iconimage='', logos='', info='', dados={}, isFolder=True, IsPlayable=False):
	urlParams = {'name': name, 'url': url, 'mode': mode, 'iconimage': iconimage, 'logos': logos, 'dados': dados}
	liz = xbmcgui.ListItem(name)
	liz.setContentLookup(False)
	liz.setInfo(type="video", infoLabels={ "Title": name, "Plot": info })
	liz.setArt({"icon":iconimage ,"poster": iconimage, "banner": logos, "fanart": logos, "thumb": iconimage })
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
# --------------------------------------------------
def OpenURL(url, headers={}, user_data={}, cookieJar=None, justCookie=False):
	req = Request(url)
	headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100110 Firefox/11.0'
	for k, v in headers.items():
		req.add_header(k, v)
	#if not 'User-Agent' in headers:
		#req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100110 Firefox/11.0')
	return urlopen(req).read().decode("utf-8").replace("\r", "")
#----------------------------------------
Sortxbmc=["SORT_METHOD_UNSORTED","SORT_METHOD_LABEL","SORT_METHOD_LASTPLAYED","SORT_METHOD_VIDEO_RATING","SORT_METHOD_DATE","SORT_METHOD_GENRE"]
def setViewS():
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	for s in Sortxbmc:
		xbmcplugin.addSortMethod(int(sys.argv[1]), eval("xbmcplugin."+s))
	xbmc.executebuiltin("Container.SetViewMode(50)")
def setViewS2():
	xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	for s in Sortxbmc:
		xbmcplugin.addSortMethod(int(sys.argv[1]), eval("xbmcplugin."+s))
	xbmc.executebuiltin("Container.SetViewMode(55)")
def setViewS3():
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')	
	xbmc.executebuiltin("Container.SetViewMode(54)")
def setViewM():
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
def setViewM2():
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	for s in Sortxbmc:
		xbmcplugin.addSortMethod(int(sys.argv[1]), eval("xbmcplugin."+s))
	xbmc.executebuiltin("Container.SetViewMode(55)")
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		try:
			y = str(x)
		except:
			y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()
def NF(text):
	xbmc.executebuiltin("Notification({0}, {1}, {3}, {2})".format(AddonName, str(text), icon, 1000))
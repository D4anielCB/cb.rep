# -*- coding: utf-8 -*-
import xbmc
# container = xbmc.getInfoLabel('System.CurrentControlID')
# dbID = xbmc.getInfoLabel('Container(%s).ListItem.DBID' % container)
# dbType = xbmc.getInfoLabel('Container(%s).ListItem.DBTYPE' % container)
# dbType = xbmc.getInfoLabel('Container.ListItem.DBID')
# dbID = xbmc.getInfoLabel('ListItem.FolderPath').split('?')[0].rstrip('/').split('/')[-1]
dbID = xbmc.getInfoLabel('ListItem.DBID')
dbType = xbmc.getInfoLabel('ListItem.DBTYPE')
filePath = xbmc.getInfoLabel('ListItem.FolderPath')
import sys
import xbmcplugin 
import xbmcgui
import xbmcaddon
import os
import urllib.parse 
import json

def Categories(): #0
	AddDir("Test", "plugin://plugin.video.CubePlayMeta/?DL=&iconimage=420817&index=&background=None&year=&info=&logos=&episode=&name=&url=_0a5f56799.html&cache=0&metah=%7B%7D&mode=97&playcount=None", 1, isFolder=False, IsPlayable=True)
	AddDir("Test2", "a", 1, isFolder=False, IsPlayable=False)
def Test(): #1
	xbmcgui.Dialog().ok(str(dbID), str(filePath))

def AddDir(name, url, mode, isFolder=True, IsPlayable=False):
	urlParams = {'name': name, 'url': url, 'mode': mode}
	liz = xbmcgui.ListItem(name)
	#ST(mode)
	if IsPlayable:
		liz.setProperty('IsPlayable', 'true')
	u = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(urlParams))
	#ST(u)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
	
def PlayUrl(name, url):
	#ST(url)
	xbmc.log('--- Playing "{0}". {1}'.format(name, url), 2)
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
def callCB():
	import time
	#try:
	jsonQuery = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"movieid": %s, "properties": ["resume"]}, "id": "1"}' % dbID)
	jsonQuery = json.loads(jsonQuery)
	Total = jsonQuery['result']['moviedetails']['resume']['total']
	rTime = jsonQuery['result']['moviedetails']['resume']['position']
	options = []
	options.append('Retomar de ' + str(time.strftime("%H:%M:%S", time.gmtime(rTime))))
	options.append('Reproduzir desde o início')
	if rTime > 0:
		selection = xbmcgui.Dialog().contextmenu(options)
	else:
		selection = 1
	#except:
		#return
		#sys.exit()
	if selection == 0:
		RS = str(100*rTime/Total)
	if selection == 1:
		RS = "0"
	elif selection == -1:
		return
		sys.exit()
	#ST(RS)
	#PlayUrl("", "plugin://plugin.video.CubePlayMeta/?DL=1&iconimage=1&index=1&background="+RS+"&year=1&info=1&logos=1&episode=1&name=1&url="+url+"&cache=0&metah=%7B%7D&mode=97&playcount=None")
	#PlayUrl("", "plugin://plugin.video.CubePlayMeta/?name=Fluidity+%282019%29&amp;url="+url+"&amp;mode=97&amp;iconimage=&amp;logos=&amp;cache=0&amp;index=&amp;info=&amp;background="+RS+"&amp;DL=&amp;year=&amp;metah=%7B%27tmdb_id%27%3A+552659%2C+%27rating%27%3A+0.0%2C+%27votes%27%3A+0%2C+%27rating.tmdb%27%3A+0.0%2C+%27votes.tmdb%27%3A+0%2C+%27popularity%27%3A+6.127%2C+%27popularity.tmdb%27%3A+6.127%2C+%27plot%27%3A+%27The+story+of+ten+millennials+living+in+New+York+City+whose+sexual+lives+intersect+in+the+age+of+social+media+-+where+likes%2C+impressions%2C+and+virtual+%22connections%22+threaten+the+very+notion+of+personal+relationships+and+human+intimacy.%27%2C+%27genre%27%3A+%5B%27Drama%27%5D%2C+%27homepage%27%3A+%27http%3A%2F%2Ffluidityfilm.com%27%2C+%27status%27%3A+%27Released%27%2C+%27writer%27%3A+%5B%27Linda+Yellen%27%2C+%27Michael+Leeds%27%2C+%27Stephanie+Wahlstrom%27%5D%2C+%27director%27%3A+%5B%5D%2C+%27media_type%27%3A+%27movie%27%2C+%27title%27%3A+%27Fluidity%27%2C+%27originaltitle%27%3A+%27Fluidity%27%2C+%27premiered%27%3A+%272019-06-21%27%2C+%27year%27%3A+2019%2C+%27tagline%27%3A+%5B%27Drama%27%5D%2C+%27runtime%27%3A+94.0%2C+%27imdbnumber%27%3A+%27tt5482242%27%2C+%27budget%27%3A+0%2C+%27budget.formatted%27%3A+%270%27%2C+%27revenue%27%3A+0%2C+%27revenue.formatted%27%3A+%270%27%2C+%27studio%27%3A+%5B%27Keckins+Projects%27%5D%2C+%27country%27%3A+%5B%27United+States+of+America%27%5D%2C+%27tag%27%3A+%5B%5D%2C+%27trailer%27%3A+%27plugin%3A%2F%2Fplugin.video.youtube%2F%3Faction%3Dplay_video%26videoid%3DUTrcBLhiywM%27%2C+%27Duration%27%3A+%271%3A34%27%2C+%27Duration.Hours%27%3A+1%2C+%27Duration.Minutes%27%3A+34%2C+%27Runtime%27%3A+94%2C+%27RuntimeExtended%27%3A+%2794+Minutes%27%2C+%27DurationAndRuntime%27%3A+%271%3A34+%2894+min.%29%27%2C+%27DurationAndRuntimeExtended%27%3A+%271%3A34+%2894+Minutes%29%27%2C+%27mediatype%27%3A+%27tvshow%27%2C+%27Imdbnumber%27%3A+%27tt5482242%27%7D&amp;episode=&amp;playcount=None")
	PlayUrl("", "plugin://plugin.video.CubePlayMeta/?name=Fluidity&url="+url+"&mode=97&iconimage=&logos=&cache=0&index=&info=&background="+RS+"&DL=&year=&metah={}&episode=&playcount=")
	
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()

params = urllib.parse.parse_qs( sys.argv[2][1:] ) 
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = int(params.get('mode', '0')[0]) if params.get('mode') else 0

if mode == 0:
	Categories()
if mode == 1:
	PlayUrl(name, url)
if mode == 2:
	Test()
if mode == 3:
	callCB()

xbmcplugin.endOfDirectory(int(sys.argv[1]))

# -*- coding: utf-8 -*-
import sys
import json
import urllib.parse
import urllib.request
# Adicionado 'xbmc' para executar comandos internos e verificar o sistema
import xbmc
# Módulos do Kodi para a interface
import xbmcplugin
from xbmcgui import ListItem, Dialog
from xbmcaddon import Addon

# --- Constantes e Configurações do Addon ---

ADDON = Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

API_KEY = ADDON.getSetting('api_key')
LANG = ADDON.getSetting('language') or 'pt-BR'
REGION = ADDON.getSetting('region') or 'BR'
POSTER_SIZE = ADDON.getSetting('poster_size') or 'w500'
BACKDROP_SIZE = ADDON.getSetting('backdrop_size') or 'w780'
RELEASE_YEAR = ADDON.getSetting('release_year') or 'Todos'

GENRE_INDEX = int(ADDON.getSetting('with_genres') or '0')
# CORREÇÃO: Corrigido o ID do gênero Família de 107S51 para 10751
GENRE_MAP_IDS = ["0", "28", "16", "12", "35", "80", "99", "18", "10751", "14", "27", "878", "53"]
GENRE = GENRE_MAP_IDS[GENRE_INDEX]

TMDB_API_BASE = 'https://api.themoviedb.org/3'
IMG_BASE_URL = 'https://image.tmdb.org/t/p'

# --- Cache para Gêneros ---
GENRE_NAME_CACHE = {}

# --- Funções Utilitárias ---

def build_url(query):
    """Cria uma URL válida para o Kodi chamar o addon novamente com novos parâmetros."""
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def http_get(url):
    """Executa uma requisição HTTP GET e retorna o corpo da resposta como string."""
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            return resp.read().decode('utf-8')
    except urllib.error.HTTPError as e:
        Dialog().notification('Erro na Requisição', f'Servidor retornou: {e.code} {e.reason}', icon=Dialog.ICON_ERROR, time=5000)
        return None
    except urllib.error.URLError as e:
        Dialog().notification('Erro de Conexão', f'Não foi possível conectar: {e.reason}', icon=Dialog.ICON_ERROR, time=5000)
        return None

def format_image(path, size):
    """Formata a URL completa para um pôster ou fanart."""
    if not path:
        return ''
    return f"{IMG_BASE_URL}/{size}{path}"

def ensure_api_key():
    """Verifica se a API Key foi configurada."""
    if not API_KEY:
        Dialog().ok('TMDb Filmes', 'Configure sua Chave de API do TMDb nas configurações.')
        ADDON.openSettings()
        return False
    return True

def get_genre_name_map():
    """Busca e armazena em cache o mapa de IDs de gênero para nomes."""
    global GENRE_NAME_CACHE
    if GENRE_NAME_CACHE:
        return GENRE_NAME_CACHE
    try:
        url = f"{TMDB_API_BASE}/genre/movie/list?api_key={API_KEY}&language={LANG}"
        response_text = http_get(url)
        if response_text:
            data = json.loads(response_text)
            GENRE_NAME_CACHE = {genre['id']: genre['name'] for genre in data.get('genres', [])}
            return GENRE_NAME_CACHE
    except Exception:
        return {}
    return {}

def set_view_and_sort_methods():
    """Define o tipo de conteúdo, os métodos de ordenação e o modo de visualização."""
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
    xbmc.executebuiltin("Container.SetViewMode(50)")

# --- Funções de Construção de Lista ---

def _create_movie_list_items(movies):
    """Função auxiliar para criar e adicionar itens de filme à lista do Kodi."""
    genre_name_map = get_genre_name_map()
    for movie in movies:
        title = movie.get('title')
        original_title = movie.get('original_title')
        original_language = movie.get('original_language')

        # Define o título final a ser usado
        final_title = title or original_title or 'Sem título'

        # Se o idioma original for asiático e os títulos forem diferentes, mostra ambos
        if original_language in ['ja', 'ko', 'zh'] and title and original_title and title != original_title:
            final_title = f"{title} ({original_title})"

        rating = float(movie.get('vote_average', 0))
        display_label = f'{final_title}  ★ {rating:.1f}'
        
        li = ListItem(label=display_label)
        li.setArt({'poster': format_image(movie.get('poster_path'), POSTER_SIZE), 'fanart': format_image(movie.get('backdrop_path'), BACKDROP_SIZE)})
        genre_ids = movie.get('genre_ids', [])
        genre_names = [genre_name_map.get(gid) for gid in genre_ids if genre_name_map.get(gid)]
        
        li.setInfo('video', { 
            'title': display_label, # Usa o título final para consistência
            'plot': movie.get('overview', ''), 
            'premiered': movie.get('release_date', ''),
            'rating': rating, 
            'votes': movie.get('vote_count', 0), 
            'genre': ' / '.join(genre_names)
        })
        li.setProperty('IsPlayable', 'false')
        
        collection_url = build_url({'action': 'show_collection', 'tmdb_id': movie.get('id')})
        recommendations_url = build_url({'action': 'show_recommendations', 'tmdb_id': movie.get('id')})
        context_menus = [
            ('Ver Coleção', f'Container.Update({collection_url})'),
            ('Ver Recomendações', f'Container.Update({recommendations_url})')
        ]
        li.addContextMenuItems(context_menus)

        url = build_url({'action': 'open_stremio', 'tmdb_id': movie.get('id'), 'title': final_title})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

def process_movie_list(endpoint, url_params, search_query=None):
    """Função genérica para buscar e exibir uma lista de filmes com paginação."""
    url = f"{TMDB_API_BASE}{endpoint}?" + urllib.parse.urlencode(url_params)
    response_text = http_get(url)
    if not response_text:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    try:
        data = json.loads(response_text)
    except json.JSONDecodeError:
        Dialog().notification('Erro de Processamento', 'Resposta da API inválida.', icon=Dialog.ICON_ERROR, time=5000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    set_view_and_sort_methods()
    results = data.get('results', [])

    if not results:
        Dialog().notification('TMDb Filmes', 'Nenhum filme encontrado.', time=3000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    _create_movie_list_items(results)

    current_page = data.get('page', 1)
    total_pages = data.get('total_pages', 1)
    if current_page < total_pages:
        next_page_num = current_page + 1
        next_li = ListItem(label=f"Próxima Página ({next_page_num}/{total_pages})")
        next_page_params = {'page': next_page_num}
        if search_query:
            next_page_params['action'] = 'search'
            next_page_params['query'] = search_query
        else:
            next_page_params['action'] = 'list'
            next_page_params['category'] = url_params.get('category', 'popular')
        xbmcplugin.addDirectoryItem(HANDLE, build_url(next_page_params), next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

# --- Funções de Ação ---

def list_movies(category, page=1):
    """Prepara os parâmetros para listar filmes de uma categoria."""
    if not ensure_api_key():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    url_params = { 'api_key': API_KEY, 'language': LANG, 'region': REGION, 'page': page }
    use_year_filter = RELEASE_YEAR != 'Todos' and category == 'popular'
    use_genre_filter = GENRE != '0' and category == 'popular'

    if use_year_filter or use_genre_filter:
        endpoint = '/discover/movie'
        url_params['sort_by'] = 'popularity.desc'
        if use_year_filter:
            url_params['primary_release_year'] = RELEASE_YEAR
        if use_genre_filter:
            url_params['with_genres'] = GENRE
    else:
        endpoint = f'/movie/{category}'

    process_movie_list(endpoint, url_params)

def search_movies(query=None, page=1):
    """Prepara os parâmetros para buscar filmes."""
    if not ensure_api_key():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not query:
        dialog = Dialog()
        query = dialog.input('Buscar Filme')
        if not query:
            return

    endpoint = '/search/movie'
    url_params = { 'api_key': API_KEY, 'language': LANG, 'query': query, 'page': page }
    process_movie_list(endpoint, url_params, search_query=query)

def show_collection(tmdb_id):
    """Busca e exibe os filmes de uma coleção."""
    if not ensure_api_key(): return
    
    details_url = f"{TMDB_API_BASE}/movie/{tmdb_id}?api_key={API_KEY}&language={LANG}"
    details_text = http_get(details_url)
    if not details_text: return
    
    collection_info = json.loads(details_text).get('belongs_to_collection')
    if not collection_info:
        Dialog().notification('TMDb Filmes', 'Este filme não pertence a uma coleção.', time=3000)
        return

    collection_url = f"{TMDB_API_BASE}/collection/{collection_info['id']}?api_key={API_KEY}&language={LANG}"
    collection_text = http_get(collection_url)
    if not collection_text: return
        
    collection_movies = json.loads(collection_text).get('parts', [])
    set_view_and_sort_methods()
    _create_movie_list_items(collection_movies)
    xbmcplugin.endOfDirectory(HANDLE)

def show_recommendations(tmdb_id):
    """Busca e exibe filmes recomendados."""
    if not ensure_api_key(): return

    reco_url = f"{TMDB_API_BASE}/movie/{tmdb_id}/recommendations?api_key={API_KEY}&language={LANG}"
    reco_text = http_get(reco_url)
    if not reco_text: return

    results = json.loads(reco_text).get('results', [])
    if not results:
        Dialog().notification('TMDb Filmes', 'Nenhuma recomendação encontrada.', time=3000)
        return

    set_view_and_sort_methods()
    _create_movie_list_items(results)
    xbmcplugin.endOfDirectory(HANDLE)

def open_stremio(tmdb_id, title):
    """Abre o filme selecionado no Stremio."""
    dialog = Dialog()
    if not dialog.yesno('Abrir no Stremio', f'Deseja abrir "{title}" no Stremio?'):
        return

    try:
        details_url = f"{TMDB_API_BASE}/movie/{tmdb_id}?api_key={API_KEY}"
        imdb_id = json.loads(http_get(details_url)).get('imdb_id')
        if not imdb_id:
            dialog.notification('Erro', 'ID do IMDb não encontrado.', icon=Dialog.ICON_ERROR)
            return

        stremio_uri = f'stremio:///detail/movie/{imdb_id}'
        cmd = None
        if xbmc.getCondVisibility('System.Platform.Android'):
            cmd = f'StartAndroidActivity("com.stremio.one", "android.intent.action.VIEW", "", "{stremio_uri}")'
        elif xbmc.getCondVisibility('System.Platform.Windows'):
            cmd = f'System.Exec("start {stremio_uri}")'
        else:
            dialog.notification('Não suportado', 'Abertura automática não suportada neste sistema.', icon=Dialog.ICON_WARNING)
            return
        if cmd: xbmc.executebuiltin(cmd)
    except Exception as e:
        dialog.notification('Erro', f'Falha ao tentar abrir no Stremio: {e}', icon=Dialog.ICON_ERROR)

def list_categories():
    """Exibe o menu principal."""
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'list', 'category': 'popular'}), ListItem(label='Filmes Populares'), isFolder=True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'list', 'category': 'upcoming'}), ListItem(label='Próx. Lançamentos (sem filtros)'), isFolder=True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'search'}), ListItem(label='Buscar Filmes...'), isFolder=True)
    
    xbmcplugin.setContent(HANDLE, 'files')
    xbmc.executebuiltin("Container.SetViewMode(50)")
    
    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    """Analisa os parâmetros da URL e direciona para a função correta."""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if action == 'list':
        list_movies(params.get('category', 'popular'), int(params.get('page', '1')))
    elif action == 'search':
        search_movies(params.get('query'), int(params.get('page', '1')))
    elif action == 'show_collection':
        show_collection(params.get('tmdb_id'))
    elif action == 'show_recommendations':
        show_recommendations(params.get('tmdb_id'))
    elif action == 'open_stremio':
        open_stremio(params.get('tmdb_id'), params.get('title'))
    elif action == 'reload_settings':
        xbmc.executebuiltin("Container.Refresh()")
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])

import time, xbmc, os, xbmcaddon

def ST(x):
	x = str(x)
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') ).decode("utf-8")
	py = os.path.join( Path, "study.txt")
	#file = open(py, "a+")
	file = open(py, "w")
	file.write(x)
	file.close()

def lup():
	#xbmc.executebuiltin("Notification({0}, {1}, 5000, {2})".format("", "Iniciou", ""))
	xbmc.executebuiltin('RunPlugin(plugin://plugin.video.CubePlayMeta/?DL=&amp;iconimage=&amp;index=&amp;background=&amp;year=&amp;info=&amp;logos=&amp;episode=&amp;name=&amp;url=&amp;cache=&amp;metah=%7B%7D&amp;mode=100&amp;playcount=None&quot;)')

if __name__ == '__main__':
	monitor = xbmc.Monitor()
	try:
		lup()
		pass
	except:
		pass
    
	while not monitor.abortRequested():
		# Sleep/wait for abort for 10 seconds
		if monitor.waitForAbort(18000):
			# Abort was requested while waiting. We should exit
			break
		lup()
		#xbmc.executebuiltin('RunPlugin(plugin://plugin.video.CubePlayMeta/?DL=&amp;iconimage=&amp;index=&amp;background=&amp;year=&amp;info=&amp;logos=&amp;episode=&amp;name=&amp;url=&amp;cache=&amp;metah=%7B%7D&amp;mode=200&amp;playcount=None&quot;)')
		#xbmc.log("hello addon! 2 %s" % time.time(), level=xbmc.LOGNOTICE)
		#xbmc.executebuiltin("Notification({0}, {1}, 5000, {2})".format("", "a", ""))